#include <omp.h>
#include <iostream>
#include <sstream>

int main(){

#pragma omp parallel 
{
    std::stringstream ss;
    ss << "Hello from thread " << omp_get_thread_num()+1 
       << " out of " << omp_get_num_threads() << "\n";
    std::cout << ss.str();
}
}
