#!/bin/bash
#PBS -l walltime=00:01:00
#PBS -l nodes=1

module use /cvmfs/opt.usherbrooke.ca/CentOS6/Modules/modulefiles.x86_64/ 
module load python64
cd code
python3 Hello.py
