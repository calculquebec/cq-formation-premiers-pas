#include <omp.h>
#include <iostream>
#include <sstream>

int main(){
int s=0;
#pragma omp parallel for
for( int i=1;i<=1033000000;++i){
   int a = i*5.15621+10.5151;
   a -= (a*a)%i;
   if(i%101==2 || i%1001==2) s+=a;
}
//std::cout << s;
return 0;
}


